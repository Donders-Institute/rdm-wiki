############################# USER CHANGE ############################

your_DCCN_username = 'eligal'
excluded_subjects = c(1, 8, 9)

################# RUN IF NOT ALREADY INSTALLED ###################

install.packages("nlme")

######################### RUN ALL ###############################

library(nlme)

data_dir = paste('/project/3010000.05/data/', your_DCCN_username, '/', sep = '')
out_dir = paste('/project/3010000.05/results/', your_DCCN_username, '/', sep = '')

setwd(data_dir)
subjects = list.dirs(path = '.', full.names = F, recursive = F)
excluded = vector('character', length(excluded_subjects))
for (i in 1:length(excluded_subjects)){
  if (excluded_subjects[i] < 10){
    excluded[i] = paste('sub-00', excluded_subjects[i], sep = '')
  } else if (excluded_subjects[i] < 100){
    excluded[i] = paste('sub-0', excluded_subjects[i], sep = '')
  } else {
    excluded[i] = paste('sub-', excluded_subjects[i], sep = '')
  }
}

i = 1
for (subject in subjects){
  if (sum(subject == excluded) == 0){
    df_subject = read.csv2(paste(data_dir, subject, '/ses-01/beh/MadeUpData.csv', sep = ''), sep =',', header = F)
    df_subject[,5] = subject
    
    if (i == 1){df_all = df_subject} else {df_all = rbind(df_all, df_subject)}
    i = i + 1
  }
}

colnames(df_all) = c('trial', 'block', 'condition', 'rt', 'id')

df_all$condition = as.factor(df_all$condition)
df_all$rt = scale(as.numeric(df_all$rt), center = T, scale = F)
df_all$id = as.factor(df_all$id)

fit = lme(fixed = rt ~ condition + trial + block + condition:trial,
          data = df_all,
          random = ~ 1 + trial + block | id)

summary(fit)
