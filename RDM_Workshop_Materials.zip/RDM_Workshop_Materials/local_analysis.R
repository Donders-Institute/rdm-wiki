install.packages("effects")

library(effects)

plot(effect("condition:trial", fit), multiline = T, ci.style= "bars", xlab = "trial", xlim = c(0, 160))
