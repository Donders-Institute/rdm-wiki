rt = random('Normal', 1.375938, 0.182187839, [160,1]);
block = repelem([1,2,3,4], 40)';
trial = [1:160]';
condition = repelem([1,2], 80)';
condition = condition(randperm(length(condition)));
rt = rt + condition .* random('Normal', 0.082187839, 0.182187839, [160,1]) + trial./160 .* random('Normal', 0.082187839, 0.182187839, [160,1]);
results = [trial, block, condition, rt];

writematrix(results, "MadeUpData.csv")